// program to convert minutes to seconds
var i = prompt(" please enter Minutes: ")

console.log("seconds: ",i*60);