// program to display only elements containing 'a' in them from a array

let data2 = prompt("enter size");
let a = new Array();
 for(var i=0;i<data2;i++)
  { 
      a[i] = prompt("enter the string");
  }

      for( i=0;i<data2;i++)
       { 
        for(var j=0;j<(a[i].length);j++)
        {
        if(a[i][j]=='a')
        {
        console.log(a[i]);
        break;
        }
        }
        
        }