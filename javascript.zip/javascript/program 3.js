// program to search for a element in a array of strings

let data1 = ["australia","india","united states","canada"];
let numbers = [23,45,56,78];

console.log(data1[3]);
console.log(numbers[3]);