
// program to search for a particular character in a string.
// Finding index of a character
let str="i love india";
let str2="laxmikanth";
let index = str.indexOf("e");
console.log(index); 

// finding patricular character with help of indexing
let data = "Australia";
console.log(data[6]);


