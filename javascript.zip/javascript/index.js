 const name = "laxmikanth";
console.log(name);
name = "chintu";
console.log(name);