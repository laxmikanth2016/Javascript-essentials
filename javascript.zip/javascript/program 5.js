// print an array in reverse order

let arr = [23,45,56,78];
let arr2 = ["india","usa","canada","australia"];

console.log(arr.reverse());
console.log(arr2.reverse());
