
function changeImage1() {
    const ele = document.getElementById("image");
    console.log(ele.id);
    const newUrl =
      "https://uploads-ssl.webflow.com/5a9423a3f702750001758d4f/5e4699ca314e56ae3a14659e_color-names.png";
  
    ele.src = newUrl;
  }

function changeImage2() {
    const ele = document.getElementById("image");
    console.log(ele.id);
    const newUrl =
      "https://htmlcolorcodes.com/assets/images/html-color-codes-color-tutorials-903ea3cb.jpg";
  
    ele.src = newUrl;
  }


  function changeImage3() {
    const ele = document.getElementById("image");
    console.log(ele.id);
    const newUrl =
      "https://cdn.britannica.com/70/191970-050-1EC34EBE/Color-wheel-light-color-spectrum.jpg";
  
    ele.src = newUrl;
  }
