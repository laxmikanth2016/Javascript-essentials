function printValue(){
    const eles=document.getElementsByClassName('name');
    console.log(eles[0].value);
}



function printValue2(){
    const eles=document.getElementsByClassName('name');
    console.log(eles[0].value);
}