
// program to display all objects having age<30
// function age(){
// let staff = [
//     {name:"abiodun_adegbuyi",age:40,gender:"male",position:"head_developer",phone_number:0001},
//     {name:"ajayi_seun ",age:35,gender:"female",position:"head_developer2",phone_number:0002},
//     {name:"olayiwola_{samiat",age:22,gender:"female",position:"developer",phone_number:0003},
//     {name:"rookie",age:22,gender:"male",position:"developer",phone_number:0004},
//     {name:"wale",age:30,gender:"male",position:"tester",phone_number:0005},
//     {name:"elizabeth",age:28,gender:"female",position:"acccountant",phone_number:0006},
//     {name:"ijeoma",age:40,gender:"female",position:"receptionist",phone_number:0007},
//     {name:"victoria",age:25,gender:"female",position:"head_developer",phone_number:0008},
//     {name:"dr_femi",age:40,gender:"male",position:"managing_director",phone_number:0009},
//     {name:"Mr_taiwo",age:40,gender:"male",position:"head_accountant",phone_number:0010},
// ];

// let filteredArray = staff.filter(function(item){ return item.age < 30 });
// console.log(filteredArray);
// }

// age();

// program to display all objects having country india

function country(){
    let staff = [
        {name:"abiodun_adegbuyi",age:40,gender:"male",country:"india"},
        {name:"ajayi_seun ",age:35,gender:"female",country:"usa"},
        {name:"olayiwola_{samiat",age:22,gender:"female",country:"australia"},
        {name:"rookie",age:22,gender:"male",country:"india"},
        {name:"wale",age:30,gender:"male",country:"canada"},
        {name:"elizabeth",age:28,gender:"female",country:"hong kong"},
        {name:"ijeoma",age:40,gender:"female",country:"uk"},
       
    ];
    
    let filteredArray = staff.filter(function(item){ return item.country == "india" });
    console.log(filteredArray);
    }

    country();

