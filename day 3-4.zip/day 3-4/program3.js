
function display()
{
let person = {
    name:"laxmikanth",
    age :27,
    country: "india",
    hobbies:["cricket","watching tv","driving"],
}
    console.log('My object: ', person)

}

display();

display();
